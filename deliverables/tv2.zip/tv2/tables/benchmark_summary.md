Status: HISTORICAL. Source: evidence/benchmark_raw_plans.zip. Time: ms; storage: bytes. Speedup = baseline median / configuration median. IQR = median upper half - median lower half. Index size comes from historical summary, not EXPLAIN.

| scale | query | configuration | runs | median_ms | iqr_ms | min_ms | max_ms | index_bytes_historical | status | scan | representative_plan | speedup |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 50000 | Q1 | Q1_baseline | 20 | 2.6485 | 0.095 | 2.315 | 3.035 | 0 | HISTORICAL | Seq Scan | 50000_Q1_baseline_run01.json | 1.0 |
| 50000 | Q1 | Q1_indexed | 20 | 0.3225 | 0.067 | 0.291 | 0.62 | 376832 | HISTORICAL | Bitmap Heap Scan,Bitmap Index Scan | 50000_Q1_indexed_run01.json | 8.212403100775193 |
| 50000 | Q2 | Q2_baseline | 20 | 4.9535 | 0.5 | 4.787 | 8.297 | 0 | HISTORICAL | Seq Scan | 50000_Q2_baseline_run01.json | 1.0 |
| 50000 | Q2 | Q2_indexed | 20 | 0.029 | 0.0135 | 0.021 | 0.059 | 3014656 | HISTORICAL | Index Scan | 50000_Q2_indexed_run01.json | 170.8103448275862 |
| 50000 | Q3 | Q3_A | 20 | 3.678 | 0.088 | 3.59 | 3.843 | 0 | HISTORICAL | Seq Scan | 50000_Q3_A_run01.json | 1.0 |
| 50000 | Q3 | Q3_B | 20 | 3.2625 | 0.2485 | 3.087 | 4.389 | 0 | HISTORICAL | Seq Scan | 50000_Q3_B_run01.json | 1.1273563218390803 |
| 50000 | Q3 | Q3_C | 20 | 3.673 | 0.087 | 3.62 | 3.94 | 1138688 | HISTORICAL | Seq Scan | 50000_Q3_C_run01.json | 1.0013612850530902 |
| 50000 | Q3 | Q3_D | 20 | 0.1255 | 0.026 | 0.106 | 0.169 | 1138688 | HISTORICAL | Bitmap Heap Scan,Bitmap Index Scan | 50000_Q3_D_run01.json | 29.306772908366533 |
| 50000 | Q4 | Q4_baseline | 20 | 8.7325 | 0.496 | 8.383 | 11.47 | 0 | HISTORICAL | Seq Scan | 50000_Q4_baseline_run01.json | 1.0 |
| 50000 | Q4 | Q4_indexed | 20 | 8.6605 | 0.458 | 8.336 | 14.879 | 368640 | HISTORICAL | Seq Scan | 50000_Q4_indexed_run01.json | 1.008313607759367 |
| 200000 | Q1 | Q1_baseline | 20 | 16.959 | 3.647 | 13.201 | 18.504 | 0 | HISTORICAL | Seq Scan | 200000_Q1_baseline_run01.json | 1.0 |
| 200000 | Q1 | Q1_indexed | 20 | 2.8595 | 0.9275 | 2.201 | 4.264 | 1441792 | HISTORICAL | Bitmap Heap Scan,Bitmap Index Scan | 200000_Q1_indexed_run01.json | 5.930757125371568 |
| 200000 | Q2 | Q2_baseline | 20 | 28.375 | 59.0285 | 25.931 | 145.245 | 0 | HISTORICAL | Seq Scan | 200000_Q2_baseline_run01.json | 1.0 |
| 200000 | Q2 | Q2_indexed | 20 | 0.0395 | 0.023 | 0.025 | 0.116 | 11976704 | HISTORICAL | Index Scan | 200000_Q2_indexed_run01.json | 718.3544303797469 |
| 200000 | Q3 | Q3_A | 20 | 23.805 | 1.945 | 22.375 | 139.022 | 0 | HISTORICAL | Seq Scan | 200000_Q3_A_run01.json | 1.0 |
| 200000 | Q3 | Q3_B | 20 | 28.8295 | 107.282 | 23.02 | 141.803 | 0 | HISTORICAL | Seq Scan | 200000_Q3_B_run01.json | 0.8257167137827572 |
| 200000 | Q3 | Q3_C | 20 | 24.2505 | 3.4665 | 21.868 | 138.394 | 4513792 | HISTORICAL | Seq Scan | 200000_Q3_C_run01.json | 0.9816292447578401 |
| 200000 | Q3 | Q3_D | 20 | 0.874 | 0.406 | 0.524 | 1.707 | 4513792 | HISTORICAL | Bitmap Heap Scan,Bitmap Index Scan | 200000_Q3_D_run01.json | 27.236842105263158 |
| 200000 | Q4 | Q4_baseline | 20 | 34.9665 | 53.3095 | 31.501 | 142.1 | 0 | HISTORICAL | Seq Scan | 200000_Q4_baseline_run01.json | 1.0 |
| 200000 | Q4 | Q4_indexed | 20 | 36.2465 | 53.7165 | 33.54 | 144.977 | 1409024 | HISTORICAL | Seq Scan | 200000_Q4_indexed_run01.json | 0.9646862455685378 |
| 500000 | Q1 | Q1_baseline | 20 | 36.5995 | 3.043 | 32.753 | 137.343 | 0 | HISTORICAL | Seq Scan | 500000_Q1_baseline_run01.json | 1.0 |
| 500000 | Q1 | Q1_indexed | 20 | 9.0585 | 3.008 | 6.182 | 12.403 | 3563520 | HISTORICAL | Bitmap Heap Scan,Bitmap Index Scan | 500000_Q1_indexed_run01.json | 4.040348843627532 |
| 500000 | Q2 | Q2_baseline | 20 | 48.061 | 4.367 | 43.765 | 128.079 | 0 | HISTORICAL | Seq Scan | 500000_Q2_baseline_run01.json | 1.0 |
| 500000 | Q2 | Q2_indexed | 20 | 0.051 | 0.047 | 0.029 | 0.102 | 29917184 | HISTORICAL | Index Scan | 500000_Q2_indexed_run01.json | 942.372549019608 |
| 500000 | Q3 | Q3_A | 20 | 40.06 | 6.133 | 37.293 | 145.03 | 0 | HISTORICAL | Seq Scan | 500000_Q3_A_run01.json | 1.0 |
| 500000 | Q3 | Q3_B | 20 | 38.5215 | 2.1605 | 35.736 | 150.678 | 0 | HISTORICAL | Seq Scan | 500000_Q3_B_run01.json | 1.0399387355113379 |
| 500000 | Q3 | Q3_C | 20 | 42.263 | 5.9775 | 37.766 | 143.458 | 11255808 | HISTORICAL | Seq Scan | 500000_Q3_C_run01.json | 0.9478740269266263 |
| 500000 | Q3 | Q3_D | 20 | 2.2295 | 1.0445 | 1.618 | 3.691 | 11255808 | HISTORICAL | Bitmap Heap Scan,Bitmap Index Scan | 500000_Q3_D_run01.json | 17.968154294684908 |
| 500000 | Q4 | Q4_baseline | 20 | 63.2775 | 3.097 | 60.54 | 142.209 | 0 | HISTORICAL | Seq Scan | 500000_Q4_baseline_run01.json | 1.0 |
| 500000 | Q4 | Q4_indexed | 20 | 66.4795 | 4.542 | 60.333 | 70.819 | 3522560 | HISTORICAL | Seq Scan | 500000_Q4_indexed_run01.json | 0.9518347761339963 |