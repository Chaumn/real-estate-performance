Status: LIVE_MEASURED. Source: evidence/benchmark_raw_plans.zip. Time: ms; storage: bytes. Speedup = baseline median / configuration median. IQR = median upper half - median lower half. Index size is verified against per-scale PostgreSQL catalog validation; not derived from EXPLAIN.

| scale | query | configuration | runs | median_ms | iqr_ms | min_ms | max_ms | index_bytes | status | scan | representative_plan | speedup |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 50000 | Q1 | Q1_baseline | 20 | 21.7635 | 20.156 | 6.705 | 105.665 | 0 | LIVE_MEASURED | Seq Scan | 50000_Q1_baseline_run01.json | 1.0 |
| 50000 | Q1 | Q1_indexed | 20 | 1.406 | 0.544 | 1.085 | 5.931 | 376832 | LIVE_MEASURED | Bitmap Heap Scan,Bitmap Index Scan | 50000_Q1_indexed_run01.json | 15.479018492176388 |
| 50000 | Q2 | Q2_baseline | 20 | 25.616 | 15.9725 | 17.59 | 163.445 | 0 | LIVE_MEASURED | Seq Scan | 50000_Q2_baseline_run01.json | 1.0 |
| 50000 | Q2 | Q2_indexed | 20 | 0.1685 | 0.0445 | 0.13 | 0.302 | 3014656 | LIVE_MEASURED | Index Scan | 50000_Q2_indexed_run01.json | 152.02373887240356 |
| 50000 | Q3 | Q3_A | 20 | 12.689 | 6.5955 | 9.737 | 47.234 | 0 | LIVE_MEASURED | Seq Scan | 50000_Q3_A_run01.json | 1.0 |
| 50000 | Q3 | Q3_B | 20 | 14.9245 | 9.674 | 8.836 | 52.914 | 0 | LIVE_MEASURED | Seq Scan | 50000_Q3_B_run01.json | 0.8502127374451406 |
| 50000 | Q3 | Q3_C | 20 | 10.826 | 1.8755 | 8.748 | 13.281 | 1138688 | LIVE_MEASURED | Seq Scan | 50000_Q3_C_run01.json | 1.1720857195640124 |
| 50000 | Q3 | Q3_D | 20 | 0.467 | 0.1425 | 0.36 | 0.869 | 1138688 | LIVE_MEASURED | Bitmap Heap Scan,Bitmap Index Scan | 50000_Q3_D_run01.json | 27.171306209850105 |
| 50000 | Q4 | Q4_baseline | 20 | 31.6305 | 13.4585 | 26.49 | 55.292 | 0 | LIVE_MEASURED | Seq Scan | 50000_Q4_baseline_run01.json | 1.0 |
| 50000 | Q4 | Q4_indexed | 20 | 34.054 | 10.4185 | 24.38 | 61.709 | 368640 | LIVE_MEASURED | Seq Scan | 50000_Q4_indexed_run01.json | 0.9288336171962177 |
| 200000 | Q1 | Q1_baseline | 20 | 44.508 | 30.9825 | 31.626 | 312.646 | 0 | LIVE_MEASURED | Seq Scan | 200000_Q1_baseline_run01.json | 1.0 |
| 200000 | Q1 | Q1_indexed | 20 | 6.532 | 2.6605 | 4.416 | 22.562 | 1441792 | LIVE_MEASURED | Bitmap Heap Scan,Bitmap Index Scan | 200000_Q1_indexed_run01.json | 6.813839559093693 |
| 200000 | Q2 | Q2_baseline | 20 | 805.738 | 393.0405 | 279.585 | 1302.674 | 0 | LIVE_MEASURED | Seq Scan | 200000_Q2_baseline_run01.json | 1.0 |
| 200000 | Q2 | Q2_indexed | 20 | 0.1445 | 0.0415 | 0.096 | 0.277 | 11976704 | LIVE_MEASURED | Index Scan | 200000_Q2_indexed_run01.json | 5576.04152249135 |
| 200000 | Q3 | Q3_A | 20 | 173.4115 | 113.0425 | 105.48 | 606.04 | 0 | LIVE_MEASURED | Seq Scan | 200000_Q3_A_run01.json | 1.0 |
| 200000 | Q3 | Q3_B | 20 | 181.568 | 91.8895 | 101.5 | 555.268 | 0 | LIVE_MEASURED | Seq Scan | 200000_Q3_B_run01.json | 0.9550774365526964 |
| 200000 | Q3 | Q3_C | 20 | 134.167 | 62.3315 | 83.704 | 284.439 | 4513792 | LIVE_MEASURED | Seq Scan | 200000_Q3_C_run01.json | 1.2925048633419542 |
| 200000 | Q3 | Q3_D | 20 | 2.2045 | 0.56 | 1.603 | 4.536 | 4513792 | LIVE_MEASURED | Bitmap Heap Scan,Bitmap Index Scan | 200000_Q3_D_run01.json | 78.66250850533001 |
| 200000 | Q4 | Q4_baseline | 20 | 183.9545 | 98.6585 | 105.322 | 950.716 | 0 | LIVE_MEASURED | Seq Scan | 200000_Q4_baseline_run01.json | 1.0 |
| 200000 | Q4 | Q4_indexed | 20 | 202.8995 | 113.7565 | 119.12 | 1215.083 | 1409024 | LIVE_MEASURED | Seq Scan | 200000_Q4_indexed_run01.json | 0.9066286511302394 |
| 500000 | Q1 | Q1_baseline | 20 | 238.4975 | 163.311 | 123.038 | 629.265 | 0 | LIVE_MEASURED | Seq Scan | 500000_Q1_baseline_run01.json | 1.0 |
| 500000 | Q1 | Q1_indexed | 20 | 50.652 | 70.85 | 16.134 | 191.654 | 3555328 | LIVE_MEASURED | Bitmap Heap Scan,Bitmap Index Scan | 500000_Q1_indexed_run01.json | 4.708550501460949 |
| 500000 | Q2 | Q2_baseline | 20 | 266.1755 | 168.616 | 156.137 | 547.681 | 0 | LIVE_MEASURED | Seq Scan | 500000_Q2_baseline_run01.json | 1.0 |
| 500000 | Q2 | Q2_indexed | 20 | 0.1285 | 0.0375 | 0.083 | 0.315 | 29917184 | LIVE_MEASURED | Index Scan | 500000_Q2_indexed_run01.json | 2071.4046692607003 |
| 500000 | Q3 | Q3_A | 20 | 292.9045 | 179.838 | 183.154 | 806.654 | 0 | LIVE_MEASURED | Seq Scan | 500000_Q3_A_run01.json | 1.0 |
| 500000 | Q3 | Q3_B | 20 | 115.334 | 18.634 | 102.684 | 146.974 | 0 | LIVE_MEASURED | Seq Scan | 500000_Q3_B_run01.json | 2.5396197131808487 |
| 500000 | Q3 | Q3_C | 20 | 134.6745 | 16.124 | 118.321 | 159.803 | 11255808 | LIVE_MEASURED | Seq Scan | 500000_Q3_C_run01.json | 2.174906905167645 |
| 500000 | Q3 | Q3_D | 20 | 3.7085 | 0.491 | 3.091 | 4.689 | 11255808 | LIVE_MEASURED | Bitmap Heap Scan,Bitmap Index Scan | 500000_Q3_D_run01.json | 78.98193339625185 |
| 500000 | Q4 | Q4_baseline | 20 | 150.003 | 10.675 | 139.817 | 181.342 | 0 | LIVE_MEASURED | Seq Scan | 500000_Q4_baseline_run01.json | 1.0 |
| 500000 | Q4 | Q4_indexed | 20 | 389.8545 | 201.6045 | 182.501 | 1032.203 | 3522560 | LIVE_MEASURED | Seq Scan | 500000_Q4_indexed_run01.json | 0.3847666244714374 |