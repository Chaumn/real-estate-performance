Status: LIVE_MEASURED. Source: evidence/benchmark_raw_plans.zip. Time: ms; storage: bytes. Speedup = baseline median / configuration median. IQR = median upper half - median lower half. Index size comes from historical summary, not EXPLAIN.

| scale | comparison | speedup |
| --- | --- | --- |
| 50000 | Q3_A/Q3_B | 0.8502127374451406 |
| 50000 | Q3_C/Q3_D | 23.182012847965737 |
| 50000 | Q3_A/Q3_C | 1.1720857195640124 |
| 50000 | Q3_B/Q3_D | 31.958244111349035 |
| 200000 | Q3_A/Q3_B | 0.9550774365526964 |
| 200000 | Q3_C/Q3_D | 60.860512587888415 |
| 200000 | Q3_A/Q3_C | 1.2925048633419542 |
| 200000 | Q3_B/Q3_D | 82.36244046268996 |
| 500000 | Q3_A/Q3_B | 2.5396197131808487 |
| 500000 | Q3_C/Q3_D | 36.31508696238371 |
| 500000 | Q3_A/Q3_C | 2.174906905167645 |
| 500000 | Q3_B/Q3_D | 31.09990562221923 |