Status: HISTORICAL. Source: evidence/benchmark_raw_plans.zip. Time: ms; storage: bytes. Speedup = baseline median / configuration median. IQR = median upper half - median lower half. Index size comes from historical summary, not EXPLAIN.

| scale | comparison | speedup |
| --- | --- | --- |
| 50000 | Q3_A/Q3_B | 1.1273563218390803 |
| 50000 | Q3_C/Q3_D | 29.266932270916335 |
| 50000 | Q3_A/Q3_C | 1.0013612850530902 |
| 50000 | Q3_B/Q3_D | 25.99601593625498 |
| 200000 | Q3_A/Q3_B | 0.8257167137827572 |
| 200000 | Q3_C/Q3_D | 27.746567505720822 |
| 200000 | Q3_A/Q3_C | 0.9816292447578401 |
| 200000 | Q3_B/Q3_D | 32.985697940503435 |
| 500000 | Q3_A/Q3_B | 1.0399387355113379 |
| 500000 | Q3_C/Q3_D | 18.956268221574344 |
| 500000 | Q3_A/Q3_C | 0.9478740269266263 |
| 500000 | Q3_B/Q3_D | 17.278089257681096 |